package responsi.abi.covid.view.Activity;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import responsi.abi.covid.R;
import responsi.abi.covid.view.Fragment.CovidCaseFragment;
import responsi.abi.covid.view.Fragment.HospitalFragment;

public class MainActivity extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {

    private Fragment selectedFragment = new CovidCaseFragment();
    private BottomNavigationView bottomNavigationView;
    private String title;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView = findViewById(R.id.main_bottom_nav);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);

        loadFragment(selectedFragment);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.bottom_nav_kasus_covid:
                selectedFragment = new CovidCaseFragment();
                loadFragment(selectedFragment);
                title = "Covid 19 Jawa Barat";
                setTitle(title);
                break;
            case R.id.bottom_nav_rumahsakit:
                selectedFragment = new HospitalFragment();
                loadFragment(selectedFragment);
                title = "Hospital Covid 19";
                setTitle(title);
                break;
        }
        return loadFragment(selectedFragment);
    }

    private boolean loadFragment(Fragment selectedFragment) {
        if (selectedFragment != null) {
            getSupportFragmentManager()
                    .beginTransaction()
                    .replace(R.id.main_fragment_container, selectedFragment)
                    .commit();
            return true;
        }
        return false;
    }
}