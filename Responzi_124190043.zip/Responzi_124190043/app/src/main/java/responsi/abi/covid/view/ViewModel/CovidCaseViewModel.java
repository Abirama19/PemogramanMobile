package responsi.abi.covid.view.ViewModel;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;

import responsi.abi.covid.model.CovidCases.CovidCaseItem;
import responsi.abi.covid.model.CovidCases.CovidCaseResponse;
import responsi.abi.covid.services.APIMain;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CovidCaseViewModel extends ViewModel {
    private APIMain apiMain;
    private MutableLiveData<ArrayList<CovidCaseItem>> listCovidCase = new MutableLiveData<>();

    public void setCovidCase(){
        if (this.apiMain == null) {
            apiMain = new APIMain();
        }

        apiMain.getApiCovidCase().getCovidCase().enqueue(new Callback<CovidCaseResponse>() {
            @Override
            public void onResponse(Call<CovidCaseResponse> call, Response<CovidCaseResponse> response) {
                CovidCaseResponse covidCaseResponse = response.body();
                if (covidCaseResponse != null && covidCaseResponse.getData().getContent() != null) {
                    ArrayList<CovidCaseItem> covidCaseItems = covidCaseResponse.getData().getContent();
                    listCovidCase.postValue(covidCaseItems);
                }
            }

            @Override
            public void onFailure(Call<CovidCaseResponse> call, Throwable t) {

            }
        });
    }

    public LiveData<ArrayList<CovidCaseItem>> getCovidCase() {
        return listCovidCase;
    }
}
