package responsi.abi.covid.services;

import responsi.abi.covid.model.Hospital.HospitalResponse;
import retrofit2.Call;
import retrofit2.http.GET;

public interface HospitalRepository {
    @GET("sebaran_v2/jabar/faskes")
    Call<HospitalResponse> getHospital();
}
