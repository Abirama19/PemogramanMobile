package responsi.abi.covid.services;

import responsi.abi.covid.model.CovidCases.CovidCaseResponse;
import retrofit2.Call;
import retrofit2.http.GET;

public interface CovidCaseRepository {
    @GET("rekapitulasi_v2/jabar/harian")
    Call<CovidCaseResponse> getCovidCase();
}
